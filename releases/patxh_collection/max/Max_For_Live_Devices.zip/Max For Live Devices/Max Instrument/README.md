# Low Pass Filter Synthesizer 

![Low Pass Filter Synthesizer](lowpass.png)

## Requirments:

Live 10 Standard or above w/ Max For Live.